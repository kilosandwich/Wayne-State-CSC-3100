
// Program 
// Program Description :
// Author:
// Creation Date :
// Revisions:
// Date: Modified by :

#include <iostream>

//decalre two int variables, X and Y:
int Y = 1;
int X = 0;


int main()
{

	// X = (Y + 4) * 3; --> X=(1+4)*3 = 15;
	X = (Y + 4) * 3;
	std::cout << "X = " << X << std::endl;
	return 0;
}
